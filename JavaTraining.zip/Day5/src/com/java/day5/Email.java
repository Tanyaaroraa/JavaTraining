package com.java.day5;

import java.util.Scanner;

public class Email {
	
	public void ema(String username)
	{
		if (email.contains('@'))
	}
	
	public static void main(String[] args) {
		String email;
		Scanner sc = new Scanner(System.in);
		email = sc.next();
	}

}
