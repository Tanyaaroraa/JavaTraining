package com.java.day5;

public class InvalidUserException extends Exception {
	
	public InvalidUserException(String error){
		super(error);
	}

}
