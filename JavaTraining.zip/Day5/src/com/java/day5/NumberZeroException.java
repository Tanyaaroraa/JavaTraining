package com.java.day5;

public class NumberZeroException extends Exception {
	
	public NumberZeroException(String error){
		super(error);
	}

}
