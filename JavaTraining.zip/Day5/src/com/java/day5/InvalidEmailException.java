package com.java.day5;

public class InvalidEmailException extends Exception {
	
	public InvalidEmailException(String error){
	 super(error);
	

}
}
