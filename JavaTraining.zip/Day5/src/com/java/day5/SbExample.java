package com.java.day5;

public class SbExample {
	
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();
		sb.append("Welcome to Java Training   ");
		System.out.println(sb);
		sb.append("\r\n From Infinite          ");
		System.out.println(sb);
	}

}
