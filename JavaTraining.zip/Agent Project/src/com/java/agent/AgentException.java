package com.java.agent;

public class AgentException extends Exception {
	
	public AgentException(String error){
		super(error);

}
}