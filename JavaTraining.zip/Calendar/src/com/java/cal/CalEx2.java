package com.java.cal;

public class CalEx2 {
	
	public static void main(String[] args) {
		Calendar calendar
	}

}
