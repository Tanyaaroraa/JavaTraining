package com.java.employ;

public class EmployException extends Exception {
	
	public EmployException(String error){
		super(error);
	}

}
